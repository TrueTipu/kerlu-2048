'''
-monet pygame tutoriaalit tallentavat constant variableja ommaan tiedostoon helpommin katseltaviksi
-tein siis saman ja tallentelin tänne kaiken näköistä
-joitain juttuja on täällä varmaan turhaan ja joitakin ei ole vaikka pitäisi
-totuttelen siis vasta tälläisen käyttämiseen
'''

WIDTH = 720
HEIGHT = 720
FPS = 60

KEY = 5829

FONT_SIZE_1 = 70
FONT_SIZE_2 = 50
FONT_COLOR = (0, 0, 0)
TEXT_OFFSET = 140

BC_BLACK_ART = 'data/art/bc/bc_black_transparent.png'
BC_YELLOW_ART = 'data/art/bc/bc_yellow_transparent.png'

GRID_SIZE = 525
TOP_PLUS_OFFSET = 50
TOP_OFFSET = HEIGHT / 2 - GRID_SIZE / 2 + TOP_PLUS_OFFSET
LEFT_OFFSET = WIDTH / 2 - GRID_SIZE / 2

TILE_SIZE = 100
TILE_GAP = 25
TILE_ANIM_LENGTH = 3
RED_VALUE = 20

SAVE_DIRECT = 'data/saves/save_data.txt'
